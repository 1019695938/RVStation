function varargout = Main(varargin)
% MAIN MATLAB code for Main.fig
%      MAIN, by itself, creates a new MAIN or raises the existing
%      singleton*.
%
%      H = MAIN returns the handle to a new MAIN or the handle to
%      the existing singleton*.
%
%      MAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN.M with the given input arguments.
%
%      MAIN('Property','Value',...) creates a new MAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Main_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Main_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Main

% Last Modified by GUIDE v2.5 23-Jun-2019 15:27:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Main_OpeningFcn, ...
                   'gui_OutputFcn',  @Main_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before Main is made visible.
function Main_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Main (see VARARGIN)

% Choose default command line output for Main
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% This sets up the initial plot - only do when we are invisible
% so window can get raised using Main.
if strcmp(get(hObject,'Visible'),'off')
    plot(rand(5));
end

% UIWAIT makes Main wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Main_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1);

cdata1 = importdata('01_1.csv');
cdata2 = importdata('01_2.csv');
cdata3 = importdata('01_3.csv');
x = 1:681;
y = importdata('ydata.csv');

popup_sel_index = get(handles.popupmenu1, 'Value');
switch popup_sel_index
    case 1
        subplot(2,2,[1,2]);
        h1 = heatmap(x,y,cdata1);
        snapnow;
        h1.Colormap = parula;
        h1.FontSize = 0.01;
        subplot(2,2,[3,4]);
        contour(flipud(cdata1),10);
        saveas(h1,'01_1.svg');
    case 2
        subplot(2,2,[1,2]);
        h2 = heatmap(1:682,y,cdata2);
        snapnow;
        h2.Colormap = parula;
        h2.FontSize = 0.01;
        subplot(2,2,[3,4]);
        contour(flipud(cdata2),10);
        saveas(h2,'01_2.svg');
    case 3
        subplot(2,2,[1,2]);
        h3 = heatmap(x,y,cdata3);
        snapnow;
        h3.Colormap = parula;
        h3.FontSize = 0.01;
        subplot(2,2,[3,4]);
        contour(flipud(cdata3),10);
        saveas(h3,'01_3.svg');
end


% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                     ['Close ' get(handles.figure1,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figure1)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
     set(hObject,'BackgroundColor','white');
end

set(hObject, 'String', {'�¶�', 'ˮ���ܶ�', '���ʪ��'});



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

date = get(handles.edit1, 'String');
date = str2int(date);
readfilename = ['54511-AD-2017-06-', num2str(date,'%02d'), 'LV2.csv'];
writefilename1 = [num2str(date,'%02d'), '_1.csv'];    %�¶�
writefilename2 = [num2str(date,'%02d'), '_2.csv'];    %ˮ���ܶ�
writefilename3 = [num2str(date,'%02d'), '_3.csv'];    %���ʪ��
data = importdata(readfilename);
a1 = 1:4:2728;
a2 = 2:4:2728;
a3 = 3:4:2728;
b = 10:102;
ydata = data.textdata(1,12:104);
ydata = cell2mat(ydata);
ydata = strrep(ydata,'km',',');
f = fopen('ydata.csv','w');
fprintf(f, ['%s','\n'], ydata);
m1 = data.data(a1,b);
m2 = data.data(a2,b);
m3 = data.data(a3,b);
m1 = flipud(m1');
m2 = flipud(m2');
m3 = flipud(m3');
csvwrite(writefilename1,m1);
csvwrite(writefilename2,m2);
csvwrite(writefilename3,m3);


% --- Executes on key press with focus on pushbutton1 and none of its controls.
function pushbutton1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1);

cdata1 = importdata('01_1.csv');
cdata2 = importdata('01_2.csv');
cdata3 = importdata('01_3.csv');
x = 1:681;
y = importdata('ydata.csv');

popup_sel_index = get(handles.popupmenu1, 'Value');
switch popup_sel_index
    case 1
        axes(handles.axes1);
        subplot(2,2,[1,2]);
        h1 = heatmap(x,y,cdata1);
        snapnow;
        h1.Colormap = parula;
        h1.FontSize = 0.01;
        subplot(2,2,[3,4]);
        contour(flipud(cdata1),10);
        saveas(h1,'01_1.svg');
    case 2
        axes(handles.axes1);
        subplot(2,2,[1,2]);
        h2 = heatmap(1:682,y,cdata2);
        snapnow;
        h2.Colormap = parula;
        h2.FontSize = 0.01;
        subplot(2,2,[3,4]);
        contour(flipud(cdata2),10);
        saveas(h2,'01_2.svg');
    case 3
        axes(handles.axes1);
        subplot(2,2,[1,2]);
        h3 = heatmap(x,y,cdata3);
        snapnow;
        h3.Colormap = parula;
        h3.FontSize = 0.01;
        subplot(2,2,[3,4]);
        contour(flipud(cdata3),10);
        saveas(h3,'01_3.svg');
end