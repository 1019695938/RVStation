function RV(d)
date = d;
readfilename = ['54511-AD-2017-06-', num2str(date,'%02d'), 'LV2.csv'];
writefilename1 = [num2str(date,'%02d'), '_1.csv'];    %�¶�
writefilename2 = [num2str(date,'%02d'), '_2.csv'];    %ˮ���ܶ�
writefilename3 = [num2str(date,'%02d'), '_3.csv'];    %���ʪ��
data = importdata(readfilename);
a1 = 1:4:2728;
a2 = 2:4:2728;
a3 = 3:4:2728;
b = 10:102;
ydata = data.textdata(1,12:104);
ydata = cell2mat(ydata);
ydata = strrep(ydata,'km',',');
f = fopen('ydata.csv','w');
fprintf(f, ['%s','\n'], ydata);
m1 = data.data(a1,b);
m2 = data.data(a2,b);
m3 = data.data(a3,b);
m1 = flipud(m1');
m2 = flipud(m2');
m3 = flipud(m3');
csvwrite(writefilename1,m1);
csvwrite(writefilename2,m2);
csvwrite(writefilename3,m3);
% disp(ydata)
cdata1 = importdata('01_1.csv');
cdata2 = importdata('01_2.csv');
cdata3 = importdata('01_3.csv');
x = 1:681;
y = importdata('ydata.csv');

figure;
subplot(2,2,[1,2]);
h1 = heatmap(x,y,cdata1);
snapnow;
h1.Colormap = parula;
h1.FontSize = 0.01;
subplot(2,2,[3,4]);
contour(flipud(cdata1),10);
saveas(h1,'01_1.svg');

figure;
subplot(2,2,[1,2]);
h2 = heatmap(1:682,y,cdata2);
snapnow;
h2.Colormap = parula;
h2.FontSize = 0.01;
subplot(2,2,[3,4]);
contour(flipud(cdata2),10);
saveas(h2,'01_2.svg');

figure;
subplot(2,2,[1,2]);
h3 = heatmap(x,y,cdata3);
snapnow;
h3.Colormap = parula;
h3.FontSize = 0.01;
subplot(2,2,[3,4]);
contour(flipud(cdata3),10);
saveas(h3,'01_3.svg');
